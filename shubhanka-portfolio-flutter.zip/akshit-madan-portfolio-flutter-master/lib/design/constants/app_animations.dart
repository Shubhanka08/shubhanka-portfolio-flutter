class AppAnimations {
  static const String introAnimation = 'assets/animations/intro_animation.riv';
}
