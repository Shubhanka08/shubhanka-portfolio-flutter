part of 'videos_bloc.dart';

@immutable
abstract class VideosEvent {}

class VideosFetchEvent extends VideosEvent {}
