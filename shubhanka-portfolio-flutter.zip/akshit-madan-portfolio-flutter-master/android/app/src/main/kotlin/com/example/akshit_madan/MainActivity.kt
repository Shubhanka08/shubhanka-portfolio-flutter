package com.example.akshit_madan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
